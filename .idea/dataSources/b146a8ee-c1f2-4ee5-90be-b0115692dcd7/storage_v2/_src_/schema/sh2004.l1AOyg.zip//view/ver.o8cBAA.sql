create view ver as
select `a`.`ENAME` AS `员工`,ifnull(`c`.`ENAME`, '无') AS `领导`
from (`sh2004`.`emp` `a`
       left join `sh2004`.`emp` `c` on ((`c`.`EMPNO` = `a`.`MGR`)));

